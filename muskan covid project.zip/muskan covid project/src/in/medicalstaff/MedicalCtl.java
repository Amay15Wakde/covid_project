package in.medicalstaff;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.medical.dto.MedicalDto;
import in.medical.model.MedicalModel;


/**
 * Servlet implementation class MedicalCtl
 */
@WebServlet("/MedicalCtl")
public class MedicalCtl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("html/txt");
		PrintWriter out=response.getWriter();
		
		String uid=request.getParameter("uid");
		String pwd=request.getParameter("pwd");
		MedicalDto md=new MedicalDto();
		md.setUid(uid);
		md.setPwd(pwd);
	    MedicalModel lm=new MedicalModel();
		boolean flag=lm.validate(md);
		if(flag){
			response.sendRedirect("jsp/RecordView.jsp");
		}
		else{
			request.setAttribute("err","invalid userid or password!");
			RequestDispatcher rd= request.getRequestDispatcher("jsp/Medical.jsp");
			rd.forward(request, response);
		}
				
			
		}
	

}
