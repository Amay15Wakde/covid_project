package in.update.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import in.DTO.RecordDTO;
import in.covid.model.RecordModel;

public class UpdateModel {
	private static Connection con=null;
	
	public static boolean Update(RecordDTO dto){
		boolean flag=false;
		con=RecordModel.getConnectivity();
		
		try{
		PreparedStatement ps=con.prepareStatement("update patient set report=? where id=?");
		ps.setString(1,dto.getReport());
		ps.setString(2,dto.getId());
		int a=ps.executeUpdate();
		if (a>0){
			flag=true;
		}
		}
		catch(SQLException sqle){
			sqle.printStackTrace();
		}
		
		
	return flag;
	}

}
