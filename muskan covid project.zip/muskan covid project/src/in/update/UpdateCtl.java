package in.update;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.DTO.RecordDTO;
import in.covid.model.RecordModel;
import in.update.model.UpdateModel;



@WebServlet("/UpdateCtl")
public class UpdateCtl extends HttpServlet {
	
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("html/text");
        PrintWriter out =response.getWriter();
        
       String id=request.getParameter("id");
        String report=request.getParameter("report");
        
        RecordDTO dto=new RecordDTO();
        dto.setReport(report);
        dto.setId(id);
        UpdateModel um=new UpdateModel();
    	boolean flag=um.Update(dto);
    	if(flag){
    		request.setAttribute("m", "Report updated successfully");
        	RequestDispatcher rd=request.getRequestDispatcher("jsp/Logoutview.jsp");
        	rd.forward(request, response);
        	
    	}
    	else{
    	response.sendRedirect("jsp/UpdateView.jsp");
    
    	
	}

	}
}
