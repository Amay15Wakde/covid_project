package in.lab.ctl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.lab.model.LabModel;
import in.medical.dto.MedicalDto;
import in.medical.model.MedicalModel;

/**
 * Servlet implementation class LabCtl
 */
@WebServlet("/LabCtl")
public class LabCtl extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("html/txt");
		PrintWriter out=response.getWriter();
		
		String uid=request.getParameter("uid");
		String pwd=request.getParameter("pwd");
		MedicalDto md=new MedicalDto();
		md.setUid(uid);
		md.setPwd(pwd);
	    LabModel lm=new LabModel();
		boolean flag=lm.validate(md);
		if(flag){
			response.sendRedirect("jsp/UpdateView.jsp");
		}
		else{
			request.setAttribute("err","invalid userid or password!");
			RequestDispatcher rd= request.getRequestDispatcher("jsp/Lab.jsp");
			rd.forward(request, response);
		}
	}

}
