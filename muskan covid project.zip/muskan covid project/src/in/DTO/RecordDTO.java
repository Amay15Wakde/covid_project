package in.DTO;

public class RecordDTO {
 
	private String name=null;
	private String lname=null;
	private String age=null;
	private String city=null;
	private String contact=null;
	private String report=null;
	private String id=null;
	
	public String getName(){
		return name;
	}
	public void setName(String name){
	this.name=name;
	}
	
	public String getLname(){
		return lname;
	}
	public void setLname(String lname){
		this.lname=lname;
	}
	public String getAge(){
		return age;
	}
	public void setAge(String age){
		this.age=age;
	}
	public String getCity(){
		return city;
	}
	public void setCity(String city){
		this.city=city;
	}
	public String getContact(){
		return contact;
	}
	public void setContact(String contact){
		this.contact=contact;
	}
	public String getId(){
		return id;
	}
	public void setId(String id){
		this.id=id;
	}

	public String getReport(){
		return report;
	}
	public void setReport(String report){
		this.report=report;
	}
}
