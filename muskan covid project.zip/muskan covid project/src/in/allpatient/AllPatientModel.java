package in.allpatient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import in.DTO.RecordDTO;
import in.covid.model.RecordModel;

public class AllPatientModel {
	
	public static ArrayList allPatient(){
		RecordDTO rd=new RecordDTO();
		ArrayList<RecordDTO> al=new ArrayList<RecordDTO>();
		Connection con=RecordModel.getConnectivity();
		try{
		PreparedStatement ps=con.prepareStatement("select * from patient where report='positive'");
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			rd.setName(rs.getString(1));
			rd.setLname(rs.getString(1));
			rd.setReport(rs.getString(5));
			
			al.add(rd);
			
		}
		
		}
		catch(SQLException sqle){
			sqle.printStackTrace();
		}
	return al;
	}

}
