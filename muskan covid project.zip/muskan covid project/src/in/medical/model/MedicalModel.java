package in.medical.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import in.medical.dto.MedicalDto;
import in.covid.model.RecordModel;


public class MedicalModel {
public boolean validate(MedicalDto md){
		
		boolean flag=false;
		Connection con=RecordModel.getConnectivity();
		try{
		PreparedStatement ps=con.prepareStatement("select * from medical where uid=? && pwd=?");
		ps.setString(1, md.getUid());
		ps.setString(2, md.getPwd());
		
		ResultSet rs=ps.executeQuery(); 
		flag=rs.next();
		}
		catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return flag;
	}
}
