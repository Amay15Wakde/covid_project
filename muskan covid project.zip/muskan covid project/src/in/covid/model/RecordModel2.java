package in.covid.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.servlet.http.HttpSession;

import in.DTO.RecordDTO;

public class RecordModel2 {
private static Connection con=null;

public static Connection getConnectivity(){
	ResourceBundle rb=ResourceBundle.getBundle("in.resources.Resources"); 
	String driver=rb.getString("driver");
	String url=rb.getString("url");
	String uid=rb.getString("uid");
	String pwd=rb.getString("pwd");
	
	try{
		Class.forName(driver);
		con=DriverManager.getConnection(url,uid,pwd);
	}
	catch(ClassNotFoundException cnfe){
		cnfe.printStackTrace();
	}
	catch(SQLException sqle){
		sqle.printStackTrace();
	}
	return con;
}

public static boolean register(RecordDTO rd){
	boolean flag=false;
	con=getConnectivity();
	try{
	PreparedStatement ps=con.prepareStatement("insert into patient values(?,?,?,?,?,?,?)");
	ps.setString(1,rd.getName());
	ps.setString(2,rd.getLname());
	ps.setString(3,rd.getAge());
	ps.setString(4,rd.getCity());
	ps.setString(5,rd.getContact());
	ps.setString(6,rd.getId());
	ps.setString(7,rd.getReport());
	int a=ps.executeUpdate();
	if (a>0){
		flag=true;
	}
	}
	catch(SQLException sqle){
		sqle.printStackTrace();
	}
	
	return flag;
}
public static boolean generateId(){
	RecordDTO rd=new RecordDTO();
	boolean flag=false;
	con=getConnectivity();
	try{
	PreparedStatement ps=con.prepareStatement("select ? from patient ");
	ps.setString(1,rd.getId());
	ResultSet rs=ps.executeQuery();
	if(rs.next()){
		
	}
	}
	catch(SQLException sqle){
		sqle.printStackTrace();
	}
	return flag;
	
}
public static ArrayList allPatient(){
	RecordDTO rd=new RecordDTO();
	ArrayList<RecordDTO> al=new ArrayList<RecordDTO>();
	con=getConnectivity();
	try{
	PreparedStatement ps=con.prepareStatement("select ?,?,? from patient where report=positive");
	ResultSet rs=ps.executeQuery();
	while(rs.next()){
		rd.setName(rs.getString(0));
		rd.setLname(rs.getString(1));
		rd.setReport(rs.getString(5));
		
		al.add(rd);
		
	}
	
	}
	catch(SQLException sqle){
		sqle.printStackTrace();
	}
return al;
}
}