package in.record;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import in.DTO.RecordDTO;
import in.covid.model.RecordModel;

/**
 * Servlet implementation class RecordCtl
 */
@WebServlet("/RecordCtl")
public class RecordCtl extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("html/text");
		PrintWriter out=response.getWriter();
		
		String name=request.getParameter("name");
		String lname=request.getParameter("lname");
	    String age=request.getParameter("age");
		String city=request.getParameter("city");
		String contact=request.getParameter("contact");
		HttpSession session=request.getSession();
		String id=session.getId();
        String report=null;
		//double id=Math.random();
		//int max=10;
		//int min=1;
		//int avg=max-min;
		//int gen=(int)Math.random()*avg;
		//System.out.println(gen);
		
		RecordDTO dto=new RecordDTO();
		dto.setName(name);
		dto.setLname(lname);
		dto.setAge(age);
		dto.setCity(city);
		dto.setContact(contact);
		dto.setId(id);
		dto.setReport(report);
	
	RecordModel rm=new RecordModel();
	boolean flag=rm.register(dto);
	if(flag){
		session.invalidate();
		request.setAttribute("true", "registered successfully");
		request.setAttribute("id",id);
    	RequestDispatcher rd=request.getRequestDispatcher("jsp/Logoutview.jsp");
    	rd.forward(request, response);
    	
	}
	else{
		response.sendRedirect("jsp/RecordView.jsp");
	}
	
	}
}
